# Weather Autoencoder

## Overview

This project implements a **distributed autoencoder** designed to process weather data using **PyTorch's DistributedDataParallel (DDP)**. It supports the following modes:

- ✅ **Training from scratch** (`--train`)
- 🔁 **Continuing training from a saved model** (`--start_from_model`)
- 🔍 **Inference only** (`--infer`)

The autoencoder works with **ERA5 weather data in Zarr format** and supports three variables:

- 🌡️ `t2m`: 2m temperature  
- ☀️ `ssrd`: Surface solar radiation  
- 🌧️ `tp`: Total precipitation

---

## Requirements

### Hardware
- ⚙️ NVIDIA GPU(s) recommended for optimal performance  
- 💾 Minimum 32GB RAM for full dataset processing

### Software Dependencies

- Python 3.10.11
- `torch==2.6.0` (with CUDA support)
- `numpy==1.26.4`
- `xarray==2024.3.0`
- `zarr==2.18.3`
- `dask==2025.1.0`

### Installation

Install dependencies via pip:

```bash
pip install torch==2.6.0 numpy==1.26.4 xarray==2024.3.0 zarr==2.18.3 dask==2025.1.0
